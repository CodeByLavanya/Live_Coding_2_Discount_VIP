export default {
  test: {
    forceRerunTriggers: [
      '**/tests/fixtures/**',
      '**/src/**',
    ],
  },
};
