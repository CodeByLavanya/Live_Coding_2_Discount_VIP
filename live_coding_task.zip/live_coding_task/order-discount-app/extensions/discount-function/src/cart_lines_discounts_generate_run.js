import {
  DiscountClass,
  ProductDiscountSelectionStrategy,
} from "../generated/api";

/**
 * @typedef {import("../generated/api").CartInput} RunInput
 * @typedef {import("../generated/api").CartLinesDiscountsGenerateRunResult} CartLinesDiscountsGenerateRunResult
 */

/**
 * @param {RunInput} input
 * @returns {CartLinesDiscountsGenerateRunResult}
 */

export function cartLinesDiscountsGenerateRun(input) {
  if (!input.cart.lines.length) {
    return { operations: [] };
  }

  const hasOrderDiscountClass = input.discount.discountClasses.includes(
    DiscountClass.Order,
  );
  console.log("order", hasOrderDiscountClass);

  const hasProductDiscountClass = input.discount.discountClasses.includes(
    DiscountClass.Product,
  );
  console.log("Product CLss", hasProductDiscountClass);

  if (hasProductDiscountClass) {
    console.log("Product start");

    const productsInVIP = input.cart.lines.some(
      (line) =>
        line.merchandise.__typename === "ProductVariant" &&
        line.merchandise.product?.metafield?.value === "VIP",
    );

    const ProductId = [];
    const sample = [];

    // const set = setid.map((set) => set.id);
    // input.cart.lines.filter((line) => {
    //   if (line.merchandise.product?.metafield?.value === "VIP") {
    //     ProductId.push(line.merchandise.product.id);
    //   }
    // });

    console.log("....", ProductId);
    console.log("....sample", sample);
    if (!hasOrderDiscountClass && !hasProductDiscountClass) {
      return { operations: [] };
    }

    const VIPmeta = input.cart.buyerIdentity.customer.metafield.value;

    console.log("VIP", VIPmeta);

    const isVIPCustomer = VIPmeta === "VIP";

    console.log("isvip", isVIPCustomer);
    console.log("proisvip", productsInVIP);

    // const maxCartLine = input.cart.lines.reduce((maxLine, line) => {
    //   if (
    //     line.cost.subtotalAmount.amount > maxLine.cost.subtotalAmount.amount
    //   ) {
    //     return line;
    //   }
    //   return maxLine;
    // }, input.cart.lines[0]);
    const arry = [];

    // const Vip_PRO = input.cart.lines.filter(
    //   (line) => line.merchandise.product?.metafield?.value === "VIP",
    // );
    // console.log("pro_vip", Vip_PRO);

    const setid = input.cart.lines
      .filter((line) => {
        if (line.merchandise.product?.metafield?.value === "VIP") {
          return line.merchandise.id;
        }
      })
      .map((line) => line);

    console.log("set", setid);

    setid.map((set) => arry.push(set.id));

    const setId = input.cart.lines.reduce((maxLine, line) => {
      if (line.merchandise.product?.metafield?.value === "VIP") {
        return line;
      }
      return maxLine;
    }, input.cart.lines[0]);

    // console.log("max", maxCartLine.id);
    console.log("max1", setId.id);

    console.log("arry", arry);

    const operations = [];

    // if (hasOrderDiscountClass) {
    //   operations.push({
    //     orderDiscountsAdd: {
    //       candidates: [
    //         {
    //           message: '10% OFF ORDER',
    //           targets: [
    //             {
    //               orderSubtotal: {
    //                 excludedCartLineIds: [],
    //               },
    //             },
    //           ],
    //           value: {
    //             percentage: {
    //               value: 10,
    //             },
    //           },
    //         },
    //       ],
    //       selectionStrategy: OrderDiscountSelectionStrategy.First,
    //     },
    //   });
    // }

    // console.log("line", line.id);

    if (hasProductDiscountClass && isVIPCustomer) {
      // for (const line of setid) {
      // console.log("line", line.id);
      const candidates = setid.map((set) => {
        console.log("set>>>>", set.id);
        const targets = [
          {
            cartLine: {
              id: set.id,
            },
          },
        ];
        return {
          message: "10% OFF PRODUCT",
          targets,
          value: {
            percentage: {
              value: 10,
            },
          },
        };
      });

      console.log("target", candidates);

      operations.push({
        productDiscountsAdd: {
          candidates,
          selectionStrategy: ProductDiscountSelectionStrategy.All,
        },
      });

      // }
    }

    return {
      operations,
    };
  }
}
